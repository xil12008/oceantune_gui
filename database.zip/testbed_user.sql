-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 05, 2013 at 04:41 PM
-- Server version: 5.1.66
-- PHP Version: 5.3.3-7+squeeze15

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `uwsn_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `testbed_user`
--

CREATE TABLE IF NOT EXISTS `testbed_user` (
  `user_id` int(6) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(40) CHARACTER SET utf8 NOT NULL,
  `passcode` varchar(40) CHARACTER SET utf8 NOT NULL,
  `privilege` tinyint(4) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='lxy' AUTO_INCREMENT=11 ;

--
-- Dumping data for table `testbed_user`
--

INSERT INTO `testbed_user` (`user_id`, `user_name`, `passcode`, `privilege`) VALUES
(1, 'admin', 'admin', 0),
(2, 'Peter', '1234', 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
