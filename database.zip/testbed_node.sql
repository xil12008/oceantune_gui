-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 05, 2013 at 04:40 PM
-- Server version: 5.1.66
-- PHP Version: 5.3.3-7+squeeze15

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `uwsn_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `testbed_node`
--

CREATE TABLE IF NOT EXISTS `testbed_node` (
  `node_id` int(20) NOT NULL AUTO_INCREMENT,
  `node_name` varchar(40) CHARACTER SET utf8 NOT NULL,
  `IP_addr` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `port_NUM` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`node_id`),
  KEY `node_id` (`node_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Dumping data for table `testbed_node`
--

INSERT INTO `testbed_node` (`node_id`, `node_name`, `IP_addr`, `port_NUM`, `longitude`, `latitude`, `status`) VALUES
(65, 'node_4', '166.241.213.112', '12345', -72.061795, 41.30732833, 2),
(66, 'node_2', '166.241.213.110', '12345', -72.064378, 41.302611, 2),
(67, 'node_1', '166.143.209.220', '12345', -72.05165, 41.30732, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
