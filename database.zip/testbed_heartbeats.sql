-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 05, 2013 at 04:40 PM
-- Server version: 5.1.66
-- PHP Version: 5.3.3-7+squeeze15

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `uwsn_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `testbed_heartbeats`
--

CREATE TABLE IF NOT EXISTS `testbed_heartbeats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `process_name` text NOT NULL,
  `node_id` int(11) NOT NULL,
  `timestamp_log` timestamp NULL DEFAULT NULL,
  `timestamp_check` timestamp NULL DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=250 ;

--
-- Dumping data for table `testbed_heartbeats`
--

INSERT INTO `testbed_heartbeats` (`id`, `process_name`, `node_id`, `timestamp_log`, `timestamp_check`, `status`, `note`) VALUES
(18, 'daemon', 27, '2012-12-10 22:08:31', '2012-12-10 22:11:37', 0, ''),
(17, 'daemon', 28, '2012-12-10 22:13:56', '2012-12-10 22:11:35', 0, ''),
(107, 'daemon', 57, '2013-11-01 17:37:58', '2013-11-01 17:34:01', 0, ''),
(103, 'daemon', 56, '2013-10-28 23:39:34', '2013-10-28 23:39:33', 0, ''),
(32, 'daemon', 58, '2013-10-04 19:50:06', '2013-10-04 19:46:42', 0, ''),
(50, 'daemon', 60, '2013-10-10 02:39:29', '2013-10-10 02:39:32', 0, ''),
(249, 'daemon', 66, '2013-11-12 10:17:21', '2013-11-12 10:13:41', 0, ''),
(204, 'daemon', 67, '2013-11-12 10:17:16', '2013-11-12 10:13:21', 0, '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
